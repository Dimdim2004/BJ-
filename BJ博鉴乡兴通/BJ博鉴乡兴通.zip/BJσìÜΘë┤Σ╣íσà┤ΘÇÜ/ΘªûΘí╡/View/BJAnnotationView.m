//
//  BJAnnotationView.m
//  BJ博鉴乡兴通
//
//  Created by wjc on 2025/3/3.
//

#import "BJAnnotationView.h"

@implementation BJAnnotationView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
