//
//  BJPostViewControllerDelegate.h
//  BJ博鉴乡兴通
//
//  Created by wjc on 2025/3/26.
//

#ifndef BJPostViewControllerDelegate_h
#define BJPostViewControllerDelegate_h

@protocol BJPostViewControllerDelegate <NSObject>

-(void)setPlaceholder;
-(BOOL)isLitmited;

@end
#endif /* BJPostViewControllerDelegate_h */
