//
//  BJPostImageViewController.m
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/2/27.
//

#import "BJPostImageViewController.h"
#import "BJLocationViewController.h"

@interface BJPostImageViewController ()

@end

@implementation BJPostImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}


@end
