//
//  BJUserRegisterModel.m
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/3/1.
//

#import "BJUserRegisterModel.h"

@implementation BJUserRegisterModel

@end
