//
//  BJRegisterSuccessModel.m
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/3/1.
//

#import "BJCodeSuccessModel.h"
#import "BJCodeModel.h"
@implementation BJCodeSuccessModel

@end
