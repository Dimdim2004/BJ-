//
//  BJLoginSuccessModel.m
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/3/10.
//

#import "BJLoginSuccessModel.h"

@implementation BJLoginSuccessModel

@end
