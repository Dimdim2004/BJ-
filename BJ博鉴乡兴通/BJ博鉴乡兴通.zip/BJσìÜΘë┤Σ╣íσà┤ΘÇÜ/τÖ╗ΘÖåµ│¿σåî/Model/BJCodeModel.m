//
//  BJCodeModel.m
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/3/10.
//

#import "BJCodeModel.h"

@implementation BJCodeModel

@end
