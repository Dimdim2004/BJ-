//
//  AppDelegate.h
//  BJ博鉴乡兴通
//
//  Created by wjc on 2025/1/9.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

