//
//  BJTabBarController.h
//  BJ博鉴乡兴通
//
//  Created by wjc on 2025/1/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BJTabBarController : UITabBarController

@end

NS_ASSUME_NONNULL_END
