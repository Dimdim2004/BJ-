//
//  BJPostViewController.h
//  BJ博鉴乡兴通
//
//  Created by wjc on 2025/1/20.
//

#import <UIKit/UIKit.h>
@class  BJPostView;
#import "TZImagePickerController.h"
NS_ASSUME_NONNULL_BEGIN

@interface BJPostViewController : UIViewController 
@property (nonatomic, strong) BJPostView* postView;
@end

NS_ASSUME_NONNULL_END
