//
//  BJPreviewModel.h
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/3/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BJPreviewModel : NSObject
@property (nonatomic, strong) NSString* titleString;
@property (nonatomic, strong) NSString* contetnString;
@end

NS_ASSUME_NONNULL_END
