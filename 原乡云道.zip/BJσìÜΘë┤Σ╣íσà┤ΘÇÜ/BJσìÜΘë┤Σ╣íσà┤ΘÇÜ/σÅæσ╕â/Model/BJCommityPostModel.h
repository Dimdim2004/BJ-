//
//  BJCommityPostlModel.h
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/3/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BJCommityPostModel : NSObject

@property (nonatomic, strong) NSString* titleString;
@property (nonatomic, strong) NSString* contentString;
@end

NS_ASSUME_NONNULL_END

