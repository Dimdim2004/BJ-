//
//  BJCodeModel.h
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/3/10.
//

#import <Foundation/Foundation.h>
#import "YYModel/YYModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface BJCodeModel : NSObject<YYModel>
@property (nonatomic, strong) NSString* code;
@end

NS_ASSUME_NONNULL_END
