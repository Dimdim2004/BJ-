//
//  BJDataModel.m
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/3/1.
//

#import "BJDataModel.h"

@implementation BJDataModel

@end
