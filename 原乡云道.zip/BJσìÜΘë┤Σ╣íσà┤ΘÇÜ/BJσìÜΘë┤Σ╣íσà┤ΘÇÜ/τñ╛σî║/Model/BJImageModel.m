//
//  BJImageModel.m
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/3/19.
//

#import "BJImageModel.h"

@implementation BJImageModel

@end
