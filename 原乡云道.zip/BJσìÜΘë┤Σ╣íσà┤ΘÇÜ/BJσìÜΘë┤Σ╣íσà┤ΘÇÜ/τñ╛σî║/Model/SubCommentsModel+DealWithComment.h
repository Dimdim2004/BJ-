//
//  SubCommentsModel+DealWithComment.h
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/3/14.
//

#import "BJSubCommentsModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface BJSubCommentsModel (DealWithComment)
- (NSString*)dealWithTime;
@end

NS_ASSUME_NONNULL_END
