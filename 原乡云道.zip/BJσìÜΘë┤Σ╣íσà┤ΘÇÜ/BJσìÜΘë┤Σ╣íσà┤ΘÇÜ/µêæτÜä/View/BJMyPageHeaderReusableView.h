//
//  BJMyPageFootReusableView.h
//  BJ博鉴乡兴通
//
//  Created by nanxun on 2025/3/28.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BJMyPageHeaderReusableView : UICollectionReusableView
@property (nonatomic, strong) UILabel* titleLabel;
@end

NS_ASSUME_NONNULL_END
