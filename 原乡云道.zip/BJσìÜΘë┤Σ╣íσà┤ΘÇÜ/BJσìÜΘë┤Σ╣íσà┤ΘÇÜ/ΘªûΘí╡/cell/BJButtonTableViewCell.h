//
//  BJButtonTableViewCell.h
//  BJ博鉴乡兴通
//
//  Created by wjc on 2025/3/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BJButtonTableViewCell : UITableViewCell

@property (nonatomic, strong) UIButton *btnToMyHometown;
@property (nonatomic, strong) UIButton *btnToMap;

@end

NS_ASSUME_NONNULL_END
