//
//  BJSearchBarTableViewCell.h
//  BJ博鉴乡兴通
//
//  Created by wjc on 2025/3/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class BJSearchBar;
@interface BJSearchBarTableViewCell : UITableViewCell
@property (nonatomic,strong) BJSearchBar *searchBar;
@end

NS_ASSUME_NONNULL_END
