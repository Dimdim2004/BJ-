//
//  BJAnnotationView.h
//  BJ博鉴乡兴通
//
//  Created by wjc on 2025/3/3.
//

#import <MapKit/MapKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BJAnnotationView : MKAnnotationView

@end

NS_ASSUME_NONNULL_END
