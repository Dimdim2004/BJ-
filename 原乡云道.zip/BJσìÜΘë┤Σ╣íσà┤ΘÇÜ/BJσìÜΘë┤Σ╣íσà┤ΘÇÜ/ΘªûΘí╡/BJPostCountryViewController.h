//
//  BJPostCountryViewController.h
//  BJ博鉴乡兴通
//
//  Created by wjc on 2025/3/26.
//

#import "BJPostCommityViewController.h"
@class BJCountryModel;
NS_ASSUME_NONNULL_BEGIN

@interface BJPostCountryViewController : BJPostCommityViewController
@property (strong, nonatomic)BJCountryModel *countryModel;
@end

NS_ASSUME_NONNULL_END
